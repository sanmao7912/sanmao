var ddate=document.getElementById("ddate");
					function updatedate(){
						var dd1=new Date();
						dd1.setMinutes(dd1.getMinutes()+dd1.getTimezoneOffset()-240); 
						var tmin=dd1.getHours();
						var myYears = ( dd1.getYear() < 1900 ) ? ( 1900 + dd1.getYear() ) : dd1.getYear();
						ddate.innerHTML="美东时间: "+myYears+"-"+fixNum(dd1.getMonth()+1)+"-"+fixNum(dd1.getDate())+" "+tmin+":"+fixNum(dd1.getMinutes())+":"+fixNum(dd1.getSeconds());
						 var t=setTimeout("updatedate()",1000);
					}
					updatedate();
function fixNum(num){
		return parseInt(num)<10?'0'+num:num;
	}
