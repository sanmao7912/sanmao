$(document).ready(function(){
	$('.query').on('click', function(){$(".con1").show();$(".con2").hide();layer.open({type: 1, zIndex: 100, title: false,area: ['744px'],skin: 'layui-layer-nobg',shade: 0.7,closeBtn :true,shadeClose: true,content: $('#querycon')});});
	$('.check').on('click', function(){$(".con1").show();$(".con2").hide();layer.open({type: 1, zIndex: 100, title: false,area: ['744px'],skin: 'layui-layer-nobg',shade: 0.7,closeBtn :true,shadeClose: true,content: $('#querycon')});});
	$('.look').live("click",function(){
			title=$(this).attr("title");
			state=$(this).attr("state");
			if(title==""&&state==0){layer.alert("审核中，请耐心等待！",{title:"提示"})}
			if(title==""&&state!=0){layer.alert("没有回复内容！",{title:"提示"})}			
			if(title!=""){layer.alert($(this).attr("title"),{title:"回复内容"})}
	});
	setInterval(function(){$(".flicker").toggleClass("color1")},350);
	$(".checksub").click(function(){
			var uname = $("#query_user").val();
			if(uname == ""){
				layer.alert("会员帐号不能为空!");
				return false;
			}
			$(".con1").hide();
			$(".con2").fadeIn();
			queryPage(1);		
	});  
	lotterylist();
})

function getRootPath(){      
    var curWwwPath=window.document.location.href;      
    var pathName=window.document.location.pathname;      
    var pos=curWwwPath.indexOf(pathName);      
    var localhostPaht=curWwwPath.substring(0,pos);
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);      
    return(localhostPaht);  
}
var root=getRootPath();

function lotterylist() {
	$.ajax({
		url: root+'/api.php?action=list',
		dataType: 'json',
		cache: false,
		type: 'GET',
		success: function(obj) {
			var sAwardEle = "";
			$.each(obj, function(i, award) {
				sAwardEle += '<li>恭喜会员：<span class="s1">'+award.user_name+'</span>成功办理<span class="s2">'+award.active_name+'</span></li>'
			});
			$(".infoList").html(sAwardEle);
			jQuery(".apply").slide({mainCell:".bd ul",autoPlay:true,effect:"topMarquee",vis:4,interTime:50,trigger:"click"});
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			var x = 1
		}
	})
}

var pagesize = 5;
function queryPage(page) {	
	$.ajax({
		url: root+'/api.php?action=querylist&p=' + page + '&size=' + pagesize,
		dataType: 'json',
		cache: false,
		data: {
			user_name: $("#query_user").val(),
			act_id: $("#query_option").val()
		},
		type: 'GET',
		success: function(obj) {
			
			console.log(obj);
			if (obj.count != 0) {
				var sHtml1 = "";
				$.each(obj.data, function(i, award) {
					var temp = '<td>等待审核</td>';
					if (award.state == "1") {
						temp = '<td><font color="#38b291">已通过</font></td>'
					}
					if (award.state == "2") {
						temp = '<td><font color=red>已拒绝</font></td>'
					}
					sHtml1 += "<tr><td>" + award.user_name + "</td><td>" + award.apply_time + "</td>" + temp + "<td><a class='look' href='javascript:;' title='" + award.check_desc + "' state='"+award.state+"'>点击查看</a></td></tr>";
				}) 
				var sPage = Paging(page, pagesize, obj.count, 2, "queryPage", '', '', '上一页', '下一页');
				$(".pages").html(sPage);
				$("#query_content").html(sHtml1)
			} else {
				$("#query_content").html("<tr><td colspan='4'>未查询到信息</td></tr>")
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			var x = 1
		}
	})
}


function Paging(pageNum, pageSize, totalCount, skipCount, fuctionName, currentStyleName, currentUseLink, preText, nextText, firstText, lastText) {
	var returnValue = "";
	var begin = 1;
	var end = 1;
	var totalpage = Math.floor(totalCount / pageSize);
	if (totalCount % pageSize > 0) {
		totalpage++
	}
	if (preText == null) {
		firstText = "prev"
	}
	if (nextText == null) {
		nextText = "next"
	}
	begin = pageNum - skipCount;
	end = pageNum + skipCount;
	if (begin <= 0) {
		end = end - begin + 1;
		begin = 1
	}
	if (end > totalpage) {
		end = totalpage
	}
	for (count = begin; count <= end; count++) {
		if (currentUseLink) {
			if (count == pageNum) {
				returnValue += "<a class=\"" + currentStyleName + "\" href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + count.toString() + ");\">" + count.toString() + "</a> "
			} else {
				returnValue += "<a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + count.toString() + ");\">" + count.toString() + "</a> "
			}
		} else {
			if (count == pageNum) {
				returnValue += "<a class=\"" + currentStyleName + "\">" + count.toString() + "</a> "
			} else {
				returnValue += "<a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + count.toString() + ");\">" + count.toString() + "</a> "
			}
		}
	}
	if (pageNum - skipCount > 1) {
		returnValue = " ... " + returnValue
	}
	if (pageNum + skipCount < totalpage) {
		returnValue = returnValue + " ... "
	}
	if (pageNum > 1) {
		returnValue = "<a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + (pageNum - 1).toString() + ");\"> " + preText + "</a> " + returnValue
	}
	if (pageNum < totalpage) {
		returnValue = returnValue + " <a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + (pageNum + 1).toString() + ");\">" + nextText + "</a>"
	}
	if (firstText != null) {
		if (pageNum > 1) {
			returnValue = "<a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(1);\">" + firstText + "</a> " + returnValue
		}
	}
	if (lastText != null) {
		if (pageNum < totalpage) {
			returnValue = returnValue + " " + " <a href=\"javascript:void(0);\" onclick=\"" + fuctionName + "(" + totalpage.toString() + ");\">" + lastText + "</a>"
		}
	}
	return returnValue
}