
var gopage=$.cookie('gotopc');

try {
var urlhash = window.location.hash;
if (!urlhash.match("fromapp"))
{
if ((navigator.userAgent.match(/(iPhone|iPod|Android|ios|iPad)/i))&&gopage!="pc")
{
window.location="./wap.html";
}
}
}
catch(err)
{
}