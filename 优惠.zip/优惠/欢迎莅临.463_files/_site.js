﻿// ng-app
var app = angular.module('portalApp', ["ui.bootstrap", "ngAnimate", "slotGame", "lobbyNav", "portalShared"]);

// Game得奖名单
app.directive('siteGameWinner', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var winnerList = [
                { 'region': '上海', 'name': 'QINTI***', 'game': '糖果派对', 'money': '66888' },
                { 'region': '山东', 'name': 'Joker***', 'game': '连环夺宝', 'money': '89125' },
                { 'region': '广州', 'name': 'wsw52***', 'game': '喜福猴年', 'money': '54201' },
                { 'region': '北京', 'name': 'Lee23***', 'game': '森林舞会', 'money': '90812' },
                { 'region': '广西', 'name': 'Lose1***', 'game': '水浒英雄', 'money': '78016' },
                { 'region': '福建', 'name': 'Vivi9***', 'game': '抢劫银行', 'money': '90874' }
            ];

            if (angular.isDefined(attrs.set)) {
                scope.winnerList = [];

                var set = parseInt(attrs.set) || 2;

                for (var i = 0; i * set < winnerList.length; i++) {
                    scope.winnerList.push(winnerList.slice(set * i, set * (i + 1)));
                }
            } else {
                scope.winnerList = winnerList;
            }

            $(function () {
                element.slide({
                    mainCell: '.winner-wrapper',
                    autoPlay: true,
                    vis: parseInt(attrs.vis) || 1,
                    effect: 'topMarquee',
                    interTime: 75
                });
            });
        }
    };
});

$(document).ready(function () {
    //跑馬燈外掛  參考：http://aamirafridi.com/jquery/jquery-marquee-plugin
    //使用class 供應其他頁面不同跑馬燈需要時可以使用
    //如果同時不同頁面需要其他效果，請建新的
    //最新消息使用
    $('.marqueen').marquee({
        //speed in milliseconds of the marquee
        duration: 12500,
        //gap in pixels between the tickers
        gap: 50,
        //time in milliseconds before the marquee will start animating
        delayBeforeStart: 0,
        //'left' or 'right' or 'up' or 'right'
        direction: 'left',
        //true or false - should the marquee be duplicated to show an effect of continues flow
        duplicated: false,
        //hover over marquee to pause
        pauseOnHover: true
    });
});